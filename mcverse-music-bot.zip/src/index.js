import 'dotenv/config';
import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import session from 'express-session';
import bcrypt from 'bcryptjs';
import { Client, GatewayIntentBits, PermissionsBitField } from 'discord.js';
import { DisTube } from 'distube';
import { SpotifyPlugin } from '@distube/spotify';
import { SoundCloudPlugin } from '@distube/soundcloud';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(express.urlencoded({ extended: true }));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, '../views'));

// session
app.use(session({
  secret: process.env.SESSION_SECRET || 'change_this_secret',
  resave: false,
  saveUninitialized: false,
  cookie: { maxAge: 24 * 60 * 60 * 1000 } // 1 day
}));

// Simple auth middleware
function requireAuth(req, res, next) {
  if (req.session && req.session.auth) return next();
  return res.redirect('/login');
}

// routes: login, logout, dashboard, controls
app.get('/login', (req, res) => {
  res.render('login', { error: null });
});

app.post('/login', (req, res) => {
  const { username, password } = req.body;
  const envUser = process.env.DASH_USER;
  const envHash = process.env.DASH_HASH;
  if (!envUser || !envHash) return res.status(500).send('Dashboard not configured.');
  if (username !== envUser) return res.render('login', { error: 'Invalid credentials' });
  const ok = bcrypt.compareSync(password, envHash);
  if (!ok) return res.render('login', { error: 'Invalid credentials' });
  req.session.auth = true;
  res.redirect('/');
});

app.post('/logout', (req, res) => {
  req.session.destroy(() => res.redirect('/login'));
});

// protected dashboard
app.get('/', requireAuth, (req, res) => {
  const snapshot = getQueueSnapshot(process.env.GUILD_ID);
  res.render('index', { queue: snapshot });
});

// control endpoints (protected)
app.post('/skip', requireAuth, (req, res) => {
  const q = distube.getQueue(process.env.GUILD_ID);
  if (q) q.skip();
  res.redirect('/');
});
app.post('/pause', requireAuth, (req, res) => {
  const q = distube.getQueue(process.env.GUILD_ID);
  if (q) q.pause();
  res.redirect('/');
});
app.post('/resume', requireAuth, (req, res) => {
  const q = distube.getQueue(process.env.GUILD_ID);
  if (q) q.resume();
  res.redirect('/');
});
app.post('/stop', requireAuth, (req, res) => {
  const q = distube.getQueue(process.env.GUILD_ID);
  if (q) q.stop();
  res.redirect('/');
});

// Create Discord client and DisTube
const client = new Client({ intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildVoiceStates] });
const distube = new DisTube(client, {
  emitNewSongOnly: true,
  leaveOnFinish: false,
  leaveOnStop: false,
  leaveOnEmpty: false,
  plugins: [new SpotifyPlugin(), new SoundCloudPlugin()]
});

function getQueueSnapshot(guildId) {
  const q = distube.getQueue(guildId);
  if (!q) return [];
  return q.songs.map(s => ({ name: s.name, url: s.url, duration: s.formattedDuration, requestedBy: s.user?.username || 'unknown' }));
}

async function joinPersistent() {
  try {
    const guild = await client.guilds.fetch(process.env.GUILD_ID);
    const channel = await guild.channels.fetch(process.env.VOICE_CHANNEL_ID);
    if (!channel) {
      console.warn('Persistent voice channel not found.');
      return;
    }
    await distube.voices.join(channel);
    console.log('✅ Joined persistent voice channel:', channel.name);
  } catch (e) {
    console.error('Failed to join persistent VC:', e);
    setTimeout(joinPersistent, 10000);
  }
}

client.once('ready', async () => {
  console.log('Logged in as', client.user.tag);
  joinPersistent();
});

client.on('interactionCreate', async interaction => {
  if (!interaction.isChatInputCommand()) return;
  if (interaction.guildId !== process.env.GUILD_ID) {
    return interaction.reply({ content: 'This bot is restricted to the configured server.', ephemeral: true });
  }

  const djRoleName = 'DJ';
  const memberHasDJ = interaction.member.roles?.cache?.some(r => r.name === djRoleName) || interaction.member.permissions?.has(PermissionsBitField.Flags.ManageGuild);

  if (interaction.commandName === 'play') {
    const query = interaction.options.getString('query');
    const voiceChannel = interaction.member.voice.channel;
    if (!voiceChannel) return interaction.reply({ content: 'Join a voice channel first.', ephemeral: true });
    await interaction.deferReply();
    try {
      await distube.play(voiceChannel, query, { textChannel: interaction.channel, member: interaction.member });
      interaction.editReply('✅ Added to queue / playing if idle.');
    } catch (e) {
      console.error('Play error:', e);
      interaction.editReply('❌ Could not play that track.');
    }
  }

  if (interaction.commandName === 'skip') {
    if (!memberHasDJ) return interaction.reply({ content: 'You need DJ role or Manage Server permission to skip.', ephemeral: true });
    const q = distube.getQueue(interaction.guildId);
    if (!q) return interaction.reply({ content: 'Nothing is playing.', ephemeral: true });
    try { q.skip(); interaction.reply('⏭️ Skipped.'); } catch { interaction.reply({ content: 'Could not skip.', ephemeral: true }); }
  }

  if (interaction.commandName === 'queue') {
    const q = distube.getQueue(interaction.guildId);
    if (!q) return interaction.reply({ content: 'Queue is empty.', ephemeral: true });
    const lines = q.songs.map((s, i) => `${i+1}. ${s.name} (${s.formattedDuration}) — ${s.user?.username || 'unknown'}`);
    await interaction.reply({ content: '**Queue:**\n' + lines.slice(0,10).join('\n'), ephemeral: false });
  }

  if (interaction.commandName === 'pause') {
    if (!memberHasDJ) return interaction.reply({ content: 'DJ role required.', ephemeral: true });
    const q = distube.getQueue(interaction.guildId);
    if (!q) return interaction.reply({ content: 'Nothing is playing.', ephemeral: true });
    q.pause(); interaction.reply('⏸️ Paused.');
  }

  if (interaction.commandName === 'resume') {
    if (!memberHasDJ) return interaction.reply({ content: 'DJ role required.', ephemeral: true });
    const q = distube.getQueue(interaction.guildId);
    if (!q) return interaction.reply({ content: 'Nothing to resume.', ephemeral: true });
    q.resume(); interaction.reply('▶️ Resumed.');
  }

  if (interaction.commandName === 'volume') {
    if (!memberHasDJ) return interaction.reply({ content: 'DJ role required.', ephemeral: true });
    const percent = interaction.options.getInteger('percent');
    const q = distube.getQueue(interaction.guildId);
    if (!q) return interaction.reply({ content: 'Nothing is playing.', ephemeral: true });
    q.setVolume(percent);
    interaction.reply(`🔊 Volume set to ${percent}%`);
  }

  if (interaction.commandName === 'loop') {
    if (!memberHasDJ) return interaction.reply({ content: 'DJ role required.', ephemeral: true });
    const mode = interaction.options.getString('mode');
    const q = distube.getQueue(interaction.guildId);
    if (!q) return interaction.reply({ content: 'Nothing is playing.', ephemeral: true });
    if (mode === 'off') q.setRepeatMode(0);
    if (mode === 'song') q.setRepeatMode(1);
    if (mode === 'queue') q.setRepeatMode(2);
    interaction.reply(`🔁 Loop set to ${mode}`);
  }
});

// distube events
distube
  .on('playSong', (queue, song) => console.log('Playing', song.name))
  .on('addSong', (queue, song) => console.log('Added', song.name))
  .on('error', (channel, e) => console.error('Distube error', e));

app.listen(process.env.PORT || 3000, () => console.log('Web UI running on port', process.env.PORT || 3000));

client.login(process.env.DISCORD_TOKEN);
